const ErrorPage = () => {
  return (
    <h2>Page d'erreur 404</h2>
  );
}

export default ErrorPage;