const HomePage = () => {
  return (
    <h2>Page d'accueil</h2>
  );
}

export default HomePage;